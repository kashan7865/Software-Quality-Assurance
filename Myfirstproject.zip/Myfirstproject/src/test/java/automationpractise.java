import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import common.utils;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import com.relevantcodes.extentreports.ExtentTest;
import pageObject.Add_to_wishlist;
import pageObject.Buy_product;
import pageObject.Contactus;
import pageObject.User_Signup;


public class automationpractise {
    public String baseUrl = "http://automationpractice.com/index.php";
    String driverpath = "C:\\Users\\malikkas\\Downloads\\selenium\\chromedriver_win32\\chromedriver.exe";
    public WebDriver driver;

    String Product_Title;
    String Product_Quantity;
    static ExtentReports report;
    static ExtentTest test;
    Contactus contobj;
    utils utilobj;
    Add_to_wishlist wishlistobj;
    User_Signup signupobj;
    Buy_product buyproobj;

    /**
     *
     */

    @BeforeTest
    public void lauchbrowser() {
        System.setProperty("webdriver.chrome.driver", driverpath);
        driver = new ChromeDriver( );
        driver.get(baseUrl);
        driver.manage( ).deleteAllCookies( );
        driver.manage( ).window( ).maximize( );
        driver.manage( ).timeouts( ).implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage( ).timeouts( ).pageLoadTimeout(30, TimeUnit.SECONDS);
        report = new ExtentReports(System.getProperty("user.dir") + "\\test1.html");
        test = report.startTest("ExtentDemo");
        contobj = new Contactus(driver);
        utilobj = new utils( );
        wishlistobj = new Add_to_wishlist(driver);
        signupobj = new User_Signup(driver);
        buyproobj = new Buy_product(driver);
    }

    /**
     *
     * @throws InterruptedException
     */
    @Test(priority = 1)
    public void User_Signup() throws InterruptedException {

        try {
            utilobj.click(signupobj.Sign_in( ));
            test.log(LogStatus.PASS, "Click on sign_in");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Sign in Not working");
        }

        utilobj.mail_keys(signupobj.create_email( ));

        try {
            utilobj.click(signupobj.create_account( ));
            test.log(LogStatus.PASS, "E_mail Verified");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Email already register");
        }

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(5000);
        utilobj.first_name_keys(signupobj.first_name( ));
        utilobj.last_name_keys(signupobj.last_name( ));
        utilobj.password(signupobj.password( ));
        utilobj.address_keys(signupobj.address( ));
        utilobj.city_keys(signupobj.city( ));
        utilobj.postal_code_keys(signupobj.postal_code( ));
        try {
            utilobj.mobile_no_keys(signupobj.mobile_no( ));
            ;
            test.log(LogStatus.PASS, "Details Verified");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Wrong Details");
        }
        signupobj.dropdown( );

        try {
            utilobj.click(signupobj.submit_detail( ));
            test.log(LogStatus.PASS, "Register Successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Wrong details");
        }

        /*Verify_account();*/
        String name = utilobj.get_text(signupobj.user_name( ));
        try {
            Assert.assertEquals(name, "kashan malik");
            test.log(LogStatus.PASS, "User name matched");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "User name not matched");
        }

        /*Signout();*/
        String sign_out = utilobj.get_text(signupobj.sign_out( ));
        try {
            Assert.assertEquals(sign_out, "Sign out");
            test.log(LogStatus.PASS, "SignOut button is available ");
        } catch (AssertionError e) {
            test.log(LogStatus.FAIL, "Sign out button not displayed");
        }
        WebElement signout = signupobj.sign_out( );
        utilobj.click(signout);
    }


    @Test(priority = 2)
    public void buy_product() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        /*Select_product();*/
        utilobj.click(buyproobj.select_pro( ));
        js.executeScript("window.scrollBy(0,600)");

        try {
            utilobj.click(buyproobj.click_pro( ));
            test.log(LogStatus.PASS, "Product selected successfully");
        } catch (Exception e) {

            test.log(LogStatus.FAIL, "Error!");
        }
        Thread.sleep(5000);
        js.executeScript("window.scrollBy(0,400)");

        /*ADD_To_cart();*/
        try {
            utilobj.click(buyproobj.add_to_cart( ));
            test.log(LogStatus.PASS, "Click on Add to cart");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }
        Thread.sleep(5000);
        try {
            utilobj.click(buyproobj.checkout( ));
            test.log(LogStatus.PASS, "Click on proceed to checkout");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }
        Thread.sleep(5000);
        js.executeScript("window.scrollBy(0,400)");

        utilobj.click(buyproobj.checkout1( ));
        Thread.sleep(5000);
        js.executeScript("window.scrollBy(0,200)");
        utilobj.id(buyproobj.id( ));
        utilobj.password(buyproobj.password( ));
        try {
            utilobj.click(buyproobj.submit( ));
            test.log(LogStatus.PASS, "Email and password verified successfully");
        } catch (Exception e) {

            test.log(LogStatus.FAIL, "Wrong Email and password!");
        }
        Thread.sleep(5000);
        js.executeScript("window.scrollBy(0,800)");
        utilobj.click(buyproobj.checkout2( ));
        Thread.sleep(5000);
        js.executeScript("window.scrollBy(0,200)");

        utilobj.click(buyproobj.checkbox( ));
        Thread.sleep(5000);
        js.executeScript("window.scrollBy(0,400)");

        try {
            utilobj.click(buyproobj.checkout3( ));
            test.log(LogStatus.PASS, "Buy product successfully");
        } catch (Exception e) {

            test.log(LogStatus.FAIL, "Error!");
        }

        utilobj.click(signupobj.sign_out( ));
    }

    @Test(priority = 3)
    public void Add_to_wishlist() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;

        try {
            utilobj.click(wishlistobj.Sign_in( ));
            test.log(LogStatus.PASS, "Click on sign in");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,200)");

        utilobj.id(wishlistobj.id( ));
        utilobj.password(wishlistobj.password( ));
        try {
            utilobj.click(wishlistobj.submit( ));
            test.log(LogStatus.PASS, "Email and password verified");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Wrong email or password");
        }

        String u_name = utilobj.get_text(wishlistobj.user_name( ));
        try {
            Assert.assertEquals(u_name, "kashan malik");
            test.log(LogStatus.PASS, "User is signed in and name match with label");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Name not matched");
        }
        System.out.println("User name match with the label:" + u_name);

        /*Search();*/
        utilobj.search(wishlistobj.search( ));


        utilobj.click(wishlistobj.submit_search( ));
        Thread.sleep(2000);

        String product_name = wishlistobj.product_name( );
        try {
            Assert.assertEquals(product_name, "Faded Short Sleeve T-shirts");
            test.log(LogStatus.PASS, "Product name matched with the search item name");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Name not matched");
        }
        System.out.println("Product name matched:" + product_name);

        /* Add_to_Wishlist();*/
        js.executeScript("window.scrollBy(0,550)");
        Actions actions = new Actions(driver);
        WebElement wishlist_option = wishlistobj.Wishlist_option( );
        try {
            actions.moveToElement(wishlist_option).perform( );
            test.log(LogStatus.PASS, "Wishlist Option is available");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Wishlist Option not available");
        }
        Thread.sleep(2000);


        String add_to_wishlist = utilobj.get_text(wishlistobj.add_to_wishlist( ));
        Assert.assertEquals(add_to_wishlist, "Add to Wishlist");

        utilobj.click(wishlistobj.add_to_wishlist( ));
        Thread.sleep(2000);


        String message = utilobj.get_text(wishlistobj.pop_up( ));

        try {
            Assert.assertEquals(message, "Added to your wishlist.");
            test.log(LogStatus.PASS, "Product is added to wishlist successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }
        System.out.println("Product is added to wishlist successfully");

        utilobj.click(wishlistobj.close_pop_up( ));
        Thread.sleep(2000);

        /*Verify_my_wishlist_page();*/
        js.executeScript("window.scrollBy(0,0)");
        Thread.sleep(2000);

        utilobj.click(wishlistobj.user_name( ));


        /*Verify_account_title();*/
        String actual_title = driver.getTitle( );
        try {
            Assert.assertEquals(actual_title, "My account - My Store");
            test.log(LogStatus.PASS, "Product Title matched successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }
        System.out.println("Account Title matched:" + actual_title);

        /*Verify_account_heading();*/

        String acc_heading = utilobj.get_text(wishlistobj.account_heading( ));

        if (acc_heading.equalsIgnoreCase("My Account")) {
            test.log(LogStatus.PASS, "Account heading matched successfully");
            System.out.println("Account Heading match:" + acc_heading);
        } else {
            System.out.println("Account heading not matched");
            test.log(LogStatus.FAIL, "Error!");
        }

        utilobj.click(wishlistobj.click_wishlist( ));
        Thread.sleep(1000);


        /*Verify_wishlist_title();*/
        String wl_title = driver.getTitle( );
        try {
            Assert.assertEquals(wl_title, "My Store");
            test.log(LogStatus.PASS, "Wishlist Title matched successfully");
            System.out.println("Wishlist title match:" + wl_title);
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }


        /*Verify_wishlist_heading();*/
        String wl_heading = utilobj.get_text(wishlistobj.wishlist_heading( ));
        if (wl_heading.equalsIgnoreCase("MY WISHLISTS")) {
            System.out.println("WISHLIST Heading match:" + wl_heading);
            test.log(LogStatus.PASS, "Wishlist Heading matched successfully");
        } else {
            test.log(LogStatus.FAIL, "WISHLIST heading not matched");
            System.out.println("WISHLIST heading not matched");
        }
        /*Wishlist_link();*/
        js.executeScript("window.scrollBy(0,600)");
        utilobj.click(wishlistobj.click_wishlist_link( ));
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,800)");

        /*Verify_product_title();*/
        String Product_Title = utilobj.get_text(wishlistobj.product_title( ));
        try {
            Assert.assertEquals(Product_Title, "Faded Short Sleeve T-shirts");
            test.log(LogStatus.PASS, "Product title matched successfully");
            System.out.println("Product title match:" + Product_Title);
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }

        /*Verify_product_quantity();*/
        WebElement product_quantity = wishlistobj.product_quantity( );
        Product_Quantity = product_quantity.getAttribute("value");
        int a = Integer.parseInt(Product_Quantity);

        if (a > 0) {
            test.log(LogStatus.PASS, "item is available");
            System.out.println("Product Quantity Match:" + Product_Quantity);

        } else {
            test.log(LogStatus.FAIL, "Product Quantity not matched");
        }
        utilobj.click(signupobj.sign_out( ));
    }

    @Test(priority = 4)
    public void Contact_us() throws InterruptedException {

        /*Click_contactus();*/
        try {
            utilobj.click(contobj.Click_contact_us( ));
            test.log(LogStatus.PASS, "Click on contact us");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Contact us page not working");
        }

        /*Verify_Contactus_heading();*/
        String contact_heading = utilobj.get_text(contobj.get_contactus_heading( ));
        try {
            Assert.assertEquals(contact_heading, "CUSTOMER SERVICE - CONTACT US");
            test.log(LogStatus.PASS, "Contact us page heading matched successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Contact us page heading not matched");
        }

        /*Details();*/
        contobj.Subject_heading( );
        utilobj.email_address(contobj.email_addr( ));
        utilobj.ref_no(contobj.order_ref( ));
        utilobj.message(contobj.message( ));

        try {
            utilobj.click(contobj.submit( ));
            test.log(LogStatus.PASS, "Details submitted successfully");

        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Details not verified");
        }
        Thread.sleep(3000);

        /*Verify_message();*/
        String message = utilobj.get_text(contobj.verify_msg( ));
        try {
            Assert.assertEquals(message, "Your message has been successfully sent to our team.");
            test.log(LogStatus.PASS, "Message received successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Message not received");
        }

        /*Verify_home_btn();*/
        String home_button = utilobj.get_text(contobj.home( ));
        try {
            Assert.assertEquals(home_button, "Home");
            test.log(LogStatus.PASS, "Home button is available and test pass successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Home button not available");
        }
        Thread.sleep(2000);

    }

    @AfterTest
    public void close_browser() {
        report.endTest(test);
        report.flush( );
        driver.close( );
        driver.quit( );
    }
}
