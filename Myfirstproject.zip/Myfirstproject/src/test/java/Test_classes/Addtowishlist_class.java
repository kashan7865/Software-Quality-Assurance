package Test_classes;

import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 *Add a product into wishlist by applying different checks
 *
 */
public class Addtowishlist_class extends Main {

    @Test
    public void Add_to_wishlist() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;

        try {
            utilobj.click(homepageobj.Sign_in_button());
            test.log(LogStatus.PASS, "Click on sign in");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,200)");

        utilobj.input_text(signinobj.id(),"fa16bse102@gmail.com");
        utilobj.input_text(signinobj.password(),"12345");
        try {
            utilobj.click(signinobj.submit());
            test.log(LogStatus.PASS, "Email and password verified successfully");
        } catch (Exception e) {

            test.log(LogStatus.FAIL, "Wrong Email and password!");
        }

        String u_name = utilobj.get_text(myaccountpageobj.user_label());
        try {
            Assert.assertEquals(u_name, "kashan malik");
            test.log(LogStatus.PASS, "User is signed in and name match with label");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Name not matched");
        }
        System.out.println("User name match with the label:" + u_name);

        /*Search();*/
        utilobj.input_text(homepageobj.search(),"Faded short sleeve");
        utilobj.search(homepageobj.submit_search());
        Thread.sleep(2000);

        String product_name = searchproductobj.product_name();
        try {
            Assert.assertEquals(product_name, "Faded Short Sleeve T-shirts");
            test.log(LogStatus.PASS, "Product name matched with the search item name");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Name not matched");
        }
        System.out.println("Product name matched:" + product_name);

        /* Add_to_Wishlist();*/
        js.executeScript("window.scrollBy(0,550)");
        Actions actions = new Actions(driver);
        WebElement wishlist_option = searchproductobj.Wishlist_option();
        try {
            actions.moveToElement(wishlist_option).perform( );
            test.log(LogStatus.PASS, "Wishlist Option is available");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Wishlist Option not available");
        }
        Thread.sleep(2000);


        String add_to_wishlist = utilobj.get_text(searchproductobj.add_to_wishlist());
        Assert.assertEquals(add_to_wishlist, "Add to Wishlist");

        utilobj.click(searchproductobj.add_to_wishlist());
        Thread.sleep(2000);


        String message = utilobj.get_text(searchproductobj.pop_up());

        try {
            Assert.assertEquals(message, "Added to your wishlist.");
            test.log(LogStatus.PASS, "Product is added to wishlist successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }
        System.out.println("Product is added to wishlist successfully");

        utilobj.click(searchproductobj.close_pop_up( ));
        Thread.sleep(2000);

        /*Verify_my_wishlist_page();*/
        js.executeScript("window.scrollBy(0,0)");
        Thread.sleep(2000);
        utilobj.click(myaccountpageobj.user_label());

        /*Verify_account_title();*/
        String actual_title = driver.getTitle( );
        try {
            Assert.assertEquals(actual_title, "My account - My Store");
            test.log(LogStatus.PASS, "Product Title matched successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }
        System.out.println("Account Title matched:" + actual_title);

        /*Verify_account_heading();*/

        String acc_heading = utilobj.get_text(myaccountpageobj.account_heading());

        if (acc_heading.equalsIgnoreCase("My Account")) {
            test.log(LogStatus.PASS, "Account heading matched successfully");
            System.out.println("Account Heading match:" + acc_heading);
        } else {
            System.out.println("Account heading not matched");
            test.log(LogStatus.FAIL, "Error!");
        }

        utilobj.click(myaccountpageobj.my_wishlist());
        Thread.sleep(1000);


        /*Verify_wishlist_title();*/
        String wl_title = driver.getTitle( );
        try {
            Assert.assertEquals(wl_title, "My Store");
            test.log(LogStatus.PASS, "Wishlist Title matched successfully");
            System.out.println("Wishlist title match:" + wl_title);
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }
        Thread.sleep(2000);

        /*Verify_wishlist_heading();*/
        String wl_heading = utilobj.get_text(mywishlistobj.wishlist1_heading());
        if (wl_heading.equalsIgnoreCase("MY WISHLISTS")) {
            System.out.println("WISHLIST Heading match:" + wl_heading);
            test.log(LogStatus.PASS, "Wishlist Heading matched successfully");
        } else {
            test.log(LogStatus.FAIL, "WISHLIST heading not matched");
            System.out.println("WISHLIST heading not matched");
        }

        /*Wishlist_link();*/
        js.executeScript("window.scrollBy(0,600)");
        utilobj.click(mywishlistobj.wishlist_link());
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,800)");

        /*Verify_product_title();*/
         String Product_Title = utilobj.get_text(mywishlistobj.product_title());
        try {
            Assert.assertEquals(Product_Title, "Faded Short Sleeve T-shirts");
            test.log(LogStatus.PASS, "Product title matched successfully");
            System.out.println("Product title match:" + Product_Title);
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }

        /*Verify_product_quantity();*/
        WebElement product_quantity = mywishlistobj.product_quantity();
       String Product_Quantity = product_quantity.getAttribute("value");
        int a = Integer.parseInt(Product_Quantity);

        if (a > 0) {
            test.log(LogStatus.PASS, "item is available");
            System.out.println("Product Quantity Match:" + Product_Quantity);

        } else {
            test.log(LogStatus.FAIL, "Product Quantity not matched");
        }
        utilobj.click(homepageobj.sign_out());
    }

}
