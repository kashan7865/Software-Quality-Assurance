package Test_classes;


import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.util.Random;

/**
 *Testing the sign_up functionality of system
 *
 */

public class Signup_class extends Main{

    @Test
    public void User_Signup() throws InterruptedException {
        Random randomGenerator = new Random( );
        int address = randomGenerator.nextInt(2000);
        int o_ref = randomGenerator.nextInt(2000);

        try {
            utilobj.click(homepageobj.Sign_in_button( ));
            test.log(LogStatus.PASS, "Click on sign_in");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Sign in Not working");
        }
        utilobj.input_text(signinobj.create_email(),"fa16" + address + "@gmail.com");

        try {
            utilobj.click(signinobj.create_account());
            test.log(LogStatus.PASS, "E_mail Verified");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Email already register");
        }

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(5000);
        utilobj.input_text(signupobj.first_name(),"kashan");
        utilobj.input_text(signupobj.last_name(),"malik");
        utilobj.input_text(signupobj.password(),"12345");
        utilobj.input_text(signupobj.address(),"cb123asd");
        utilobj.input_text(signupobj.city(),"wah");
        utilobj.input_text(signupobj.postal_code(),"00000");
        try {
            utilobj.input_text(signupobj.mobile_no(),"0346789");
            test.log(LogStatus.PASS, "Details Verified");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Wrong Details");
        }
        signupobj.dropdown( );

        try {
            utilobj.click(signupobj.register());
            test.log(LogStatus.PASS, "Register Successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Wrong details");
        }

        /*Verify_account();*/
        String name = utilobj.get_text(myaccountpageobj.user_label());
        try {
            Assert.assertEquals(name, "kashan malik");
            test.log(LogStatus.PASS, "User name matched");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "User name not matched");
        }

        /*Signout();*/
        String sign_out = utilobj.get_text(homepageobj.sign_out());
        try {
            Assert.assertEquals(sign_out, "Sign out");
            test.log(LogStatus.PASS, "SignOut button is available ");
        } catch (AssertionError e) {
            test.log(LogStatus.FAIL, "Sign out button not displayed");
        }
        WebElement signout = homepageobj.sign_out();
        utilobj.click(signout);
    }

}
