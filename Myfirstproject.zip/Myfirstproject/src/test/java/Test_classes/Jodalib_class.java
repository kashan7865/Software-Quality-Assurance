package Test_classes;

import org.joda.time.*;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.testng.annotations.Test;
import pageObject.Jodin_methods;

/**
 *Find the duration between two weeks
 *
 */

public class Jodalib_class {

    Jodin_methods difference=new Jodin_methods();
    @Test
        public void jodatest(){
        String startdate="08/05/2021 06:00:00";
        String enddate="08/06/2021 20:05:02";

        DateTimeFormatter formatter = DateTimeFormat.forPattern("dd/MM/yyyy HH:mm:ss");
        LocalDateTime dt1 = LocalDateTime.parse( startdate , formatter ) ;
        LocalDateTime dt2= LocalDateTime.parse(enddate,formatter);

        System.out.println( "Difference between date1 :"+dt1 + " and date2 is :"+dt2 );
        System.out.println(difference.Days(dt1,dt2)+ " days,");
        System.out.println(difference.Weeks(dt1,dt2)+ " Weeks,");
        System.out.println( difference.Years(dt1,dt2)+ " Years,");
        System.out.println(difference.Hours(dt1,dt2)+" hours,");
        System.out.println(difference.Minutes(dt1,dt2)+" minutes,");
        System.out.println(difference.Seconds(dt1,dt2)+" seconds,");
    }


    @Test (priority = 2)
     public void joda_test2(){
        String startdate="04/05/2021 06:00:00";
        String enddate="08/05/2021 20:05:02";

        DateTimeFormatter formatter = DateTimeFormat.forPattern("dd/MM/yyyy HH:mm:ss");
        LocalDateTime dt1 = LocalDateTime.parse( startdate , formatter ) ;
        LocalDateTime dt2= LocalDateTime.parse(enddate,formatter);

            System.out.println( "Difference between date1 :"+dt1 + " and date2 is :"+dt2 );
            System.out.println(Days.daysBetween(dt1,dt2).getDays() + "days,");
            System.out.println(Hours.hoursBetween(dt1,dt2).getHours()+"hours,");
            System.out.println(Minutes.minutesBetween(dt1,dt2).getMinutes()+"minutes,");
            System.out.println(Seconds.secondsBetween(dt1,dt2).getSeconds()+"seconds,");

        }
    }
