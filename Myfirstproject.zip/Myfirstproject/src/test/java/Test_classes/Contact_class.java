package Test_classes;


import com.relevantcodes.extentreports.LogStatus;
import org.testng.Assert;
import org.testng.annotations.Test;
/**
 *Checking the Contact_us Functionality
 *
 */


public class Contact_class extends Main {

    @Test
    public void Contact_us() throws InterruptedException {

        /*Click_contactus();*/
        try {
            utilobj.click(homepageobj.contact_us_button( ));
            test.log(LogStatus.PASS, "Click on contact us");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Contact us page not working");
        }

        /*Verify_Contactus_heading();*/
        String contact_heading = utilobj.get_text(contactpageobj.get_contactus_heading( ));
        try {
            Assert.assertEquals(contact_heading, "CUSTOMER SERVICE - CONTACT US");
            test.log(LogStatus.PASS, "Contact us page heading matched successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Contact us page heading not matched");
        }

        /*Details();*/
        contactpageobj.Subject_heading( );
        utilobj.email_address(contactpageobj.email_addr( ));
        utilobj.ref_no(contactpageobj.order_ref( ));
        utilobj.message(contactpageobj.message( ));

        try {
            utilobj.click(contactpageobj.submit( ));
            test.log(LogStatus.PASS, "Details submitted successfully");

        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Details not verified");
        }
        Thread.sleep(3000);

        /*Verify_message();*/
        String message = utilobj.get_text(contactpageobj.verify_msg( ));
        try {
            Assert.assertEquals(message, "Your message has been successfully sent to our team.");
            test.log(LogStatus.PASS, "Message received successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Message not received");
        }

        /*Verify_home_btn();*/
        String home_button = utilobj.get_text(contactpageobj.home_button( ));
        try {
            Assert.assertEquals(home_button, "Home");
            test.log(LogStatus.PASS, "Home button is available and test pass successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Home button not available");
        }
        Thread.sleep(2000);

    }


}
