package Test_classes;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import common.utils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import pageObject.*;

import java.util.concurrent.TimeUnit;
/**
 *Main class of automation practise website include all the objects
 *
 */

public class Main {
    public String baseUrl = "http://automationpractice.com/index.php";
    String driverpath = "C:\\Users\\malikkas\\Downloads\\selenium\\chromedriver_win32\\chromedriver.exe";
    public WebDriver driver;

    static ExtentReports report;
    static ExtentTest test;
    utils utilobj;
    Home_page homepageobj;
    Signin_page signinobj;
    Sign_up_page signupobj;
    My_account_page myaccountpageobj;
    Search_product_page searchproductobj;
    Add_to_cart_page addtocartobj;
    My_wishlist_page mywishlistobj;
    Contact_us_page contactpageobj;
    Casual_dress_page casualdressobj;
    Navigation_page navigationpageobj;
    Summer_dresses_page summerdressesobj;
    lower_to_higher_page lowerhigherobj;



    @BeforeTest
    public void launchbrowser() {
        System.setProperty("webdriver.chrome.driver", driverpath);
        driver = new ChromeDriver( );
        driver.get(baseUrl);
        driver.manage( ).deleteAllCookies( );
        driver.manage( ).window( ).maximize( );
        driver.manage( ).timeouts( ).implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage( ).timeouts( ).pageLoadTimeout(30, TimeUnit.SECONDS);
        report = new ExtentReports(System.getProperty("user.dir") + "\\test1.html");
        test = report.startTest("ExtentDemo");
        utilobj = new utils( );
        homepageobj = new Home_page(driver);
        signinobj=new Signin_page(driver);
        signupobj=new Sign_up_page(driver);
        myaccountpageobj=new My_account_page(driver);
        searchproductobj=new Search_product_page(driver);
        addtocartobj=new Add_to_cart_page(driver);
        mywishlistobj=new My_wishlist_page(driver);
        contactpageobj = new Contact_us_page(driver);
        casualdressobj=new Casual_dress_page(driver);
        navigationpageobj=new Navigation_page(driver);
        summerdressesobj=new Summer_dresses_page(driver);
       lowerhigherobj=new lower_to_higher_page();

    }
    @AfterTest
    public void close_browser() {
        report.endTest(test);
        report.flush( );
        driver.close( );
        driver.quit( );
    }
}
