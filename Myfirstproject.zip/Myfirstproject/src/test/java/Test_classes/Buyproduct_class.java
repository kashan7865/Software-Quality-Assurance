package Test_classes;


import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

/**
 *Buy a product by selecting it from home page
 *
 */

public class Buyproduct_class extends Main {

     @Test
     public void buy_product() throws InterruptedException {
         JavascriptExecutor js = (JavascriptExecutor) driver;

         /*Select_product();*/
         utilobj.click(homepageobj.women_link());
         js.executeScript("window.scrollBy(0,600)");

         try {
             utilobj.click(searchproductobj.click_pro());
             test.log(LogStatus.PASS, "Product selected successfully");
         } catch (Exception e) {

             test.log(LogStatus.FAIL, "Error!");
         }
         Thread.sleep(2000);
         js.executeScript("window.scrollBy(0,400)");

         /*ADD_To_cart();*/
         try {
             utilobj.click(addtocartobj.add_to_cart_button());
             test.log(LogStatus.PASS, "Click on Add to cart");
         } catch (Exception e) {
             test.log(LogStatus.FAIL, "Error!");
         }
         Thread.sleep(5000);
         try {
             utilobj.click(addtocartobj.checkout_button());
             test.log(LogStatus.PASS, "Click on proceed to checkout");
         } catch (Exception e) {
             test.log(LogStatus.FAIL, "Error!");
         }
         Thread.sleep(5000);
         js.executeScript("window.scrollBy(0,400)");

         utilobj.click(addtocartobj.checkout1( ));
         Thread.sleep(5000);
         js.executeScript("window.scrollBy(0,200)");
         utilobj.input_text(signinobj.id(),"fa16bse102@gmail.com");
         utilobj.input_text(signinobj.password(),"12345");
         try {
             utilobj.click(signinobj.submit());
             test.log(LogStatus.PASS, "Email and password verified successfully");
         } catch (Exception e) {

             test.log(LogStatus.FAIL, "Wrong Email and password!");
         }
         Thread.sleep(3000);
         js.executeScript("window.scrollBy(0,800)");

         utilobj.click(addtocartobj.checkout2());
         Thread.sleep(3000);
         js.executeScript("window.scrollBy(0,200)");

         utilobj.click(addtocartobj.checkbox());
         Thread.sleep(5000);
         js.executeScript("window.scrollBy(0,400)");

         try {
             utilobj.click(addtocartobj.checkout3());
             test.log(LogStatus.PASS, "Buy product successfully");
         } catch (Exception e) {

             test.log(LogStatus.FAIL, "Error!");
         }

         utilobj.click(homepageobj.sign_out());
     }


}
