package Test_classes;

import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.*;

public class Page_load_verification_class extends Main {

    /**
     *Testing the casual dresses page by verifying heading and title
     *
     */
    @Test(priority = 1)
    public void Verify_product_page() throws InterruptedException {
        Actions action = new Actions(driver);
        action.moveToElement(homepageobj.women_link()).perform();
        Thread.sleep(1000);
        utilobj.click(homepageobj.casual_dresses());

        String heading = casualdressobj.page_heading().getText();
        System.out.println(heading);
        try {
            Assert.assertEquals(heading.trim(), "CASUAL DRESSES");
            test.log(LogStatus.PASS, "Product Heading matched successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");

        }

        String actual_title = driver.getTitle();
        try {
            Assert.assertEquals(actual_title, "Casual Dresses - My Store");
            test.log(LogStatus.PASS, "Product Title matched successfully");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }
        System.out.println("Account Title matched:" + actual_title);
    }

    /**
     *Clicking on submenu by passing two parameters in method
     *
     */
    @Test(priority = 2)
    public void click_submenu() {
        navigationpageobj.navigation(homepageobj.women_link(), homepageobj.summer_dresses());
        String title = driver.getTitle();
        try {
            Assert.assertEquals(title, "Summer Dresses - My Store");
            test.log(LogStatus.PASS, "Summer Product Title matched successfully ");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }
    }
    /**
     *Testing the total no of products in summer dresses page
     *
     */
    @Test(priority = 3)
    public void Verify_Total_products() {
        navigationpageobj.navigation(homepageobj.women_link(), homepageobj.summer_dresses());
        String string_line = summerdressesobj.total_items().getText();
        System.out.println("String:" + string_line);

        List<WebElement> total_products = summerdressesobj.total_products();
        String total_product_value=String.valueOf(total_products.get(17));
        int total_product= Integer.parseInt(total_product_value);
        System.out.println(" Array String: " + total_products + "\n" + " Total no of products: " + total_product);

        int total_items=summerdressesobj.total_containers();
        System.out.println("Total Containers: "+total_items);

        try {
            Assert.assertEquals(total_product,total_items);
            test.log(LogStatus.PASS, "total product matched successfully ");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error!");
        }

    }

    /**
     *Testing that summer dresses page are in ascending order
     *
     */
    @Test(priority = 4)
    public void ascending_order_products(){
        navigationpageobj.navigation(homepageobj.women_link(), homepageobj.summer_dresses());
        List<WebElement> elements=summerdressesobj.prod_price();
        /*for(int i=0;i<elements.size();i++){
            String prices=elements.get(i).getText();
            System.out.println(prices);

        }*/
        List<String> sorted= new ArrayList<String>();
        for (WebElement element : elements) {
            sorted.add(element.getText());

        }
        Collections.sort(sorted);
        System.out.println(sorted);

        List<String> unsorted = new ArrayList<String>();
        for (WebElement element : elements) {
            unsorted.add(element.getText());
        }
        System.out.println(unsorted);

        try {
            Assert.assertEquals(sorted,unsorted);
            test.log(LogStatus.PASS, "Product prices are in ascending order ");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Product prices are not in ascending order");
        }

       /* try {
            Assert.assertTrue(lowerhigherobj.sorting(sorted));
            test.log(LogStatus.PASS, "Product prices are in ascending order ");
        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Product prices are not in ascending order");
        }*/

    }
}