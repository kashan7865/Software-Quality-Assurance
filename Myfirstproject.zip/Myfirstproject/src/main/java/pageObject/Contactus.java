package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Contactus {
    WebDriver driver;

    public Contactus(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver, this);

    }
    public WebElement Click_contact_us(){
        return driver.findElement(By.xpath("//a[contains(@href,'http://automationpractice.com/index.php?controller=contact')]"));
    }
    public WebElement get_contactus_heading(){
        return driver.findElement(By.xpath("//h1[@class='page-heading bottom-indent']"));
    }
    public Select Subject_heading(){
        Select Subject_heading= new Select(driver.findElement(By.xpath("//select[@id='id_contact']")));
        Subject_heading.selectByIndex(1);
        return Subject_heading;
    }
    public WebElement email_addr(){
        return driver.findElement(By.xpath("//input[@class='form-control grey validate']"));
    }

    public WebElement order_ref(){
        return driver.findElement(By.xpath("//input[@id='id_order']"));
    }

    public WebElement message(){
        return driver.findElement(By.xpath("//textarea[@id='message']"));
    }

    public WebElement submit(){
        return driver.findElement(By.xpath("//button[@id='submitMessage']"));
    }

    public WebElement verify_msg(){
        return driver.findElement(By.xpath("//p[@class='alert alert-success']"));
    }

    public WebElement home(){
        return driver.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[3]/div[1]/ul[1]/li[1]/a[1]"));
    }
}
