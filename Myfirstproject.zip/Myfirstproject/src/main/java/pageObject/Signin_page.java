package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class Signin_page{
    WebDriver driver;

    public Signin_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    public WebElement create_email(){
        return driver.findElement(By.xpath("//input[@id='email_create']") );
    }
    public WebElement create_account(){
        return driver.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[3]/div[1]/div[1]/div[1]/form[1]/div[1]/div[3]/button[1]/span[1]"));
    }
    public WebElement id(){
        return driver.findElement(By.xpath("//input[@id='email']") );
    }
    public WebElement password(){
        return driver.findElement(By.xpath("//input[@id='passwd']") );
    }
    public WebElement submit(){
        return driver.findElement(By.xpath("//button[@id='SubmitLogin']") );
    }
}
