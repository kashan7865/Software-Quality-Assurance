package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Sign_up_page {
    WebDriver driver;

    public Sign_up_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public WebElement first_name(){
        return driver.findElement(By.xpath("//input[@id='customer_firstname']"));
    }
    public WebElement last_name(){
        return driver.findElement(By.xpath("//input[@id='customer_lastname']"));
    }
    public WebElement password(){
        return driver.findElement(By.xpath("//input[@id='passwd']"));
    }
    public WebElement address(){
        return driver.findElement(By.xpath("//input[@id='address1']"));
    }
    public WebElement city(){
        return driver.findElement(By.xpath("//input[@id='city']"));
    }
    public WebElement postal_code(){
        return driver.findElement(By.xpath("//input[@id='postcode']"));
    }
    public WebElement mobile_no(){
        return driver.findElement(By.xpath("//input[@id='phone_mobile']"));
    }
    public Select dropdown(){
        Select dropdown=new Select(driver.findElement(By.xpath("//select[@id='id_state']")));
        dropdown.selectByIndex(1);
        return dropdown;
    }
    public WebElement register(){
        return driver.findElement(By.xpath("//button[@id='submitAccount']"));
    }
}
