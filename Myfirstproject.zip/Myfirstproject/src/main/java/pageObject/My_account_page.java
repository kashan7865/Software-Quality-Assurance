package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class My_account_page {
    WebDriver driver;

    public My_account_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    public WebElement user_label(){
        return driver.findElement(By.xpath("//a[@class='account']"));
    }
    public WebElement account_heading(){
        return driver.findElement(By.xpath("//h1[contains(text(),'My account')]"));
    }
    public WebElement my_wishlist(){
        return driver.findElement(By.xpath("//span[contains(text(),'My wishlists')]"));
    }
}
