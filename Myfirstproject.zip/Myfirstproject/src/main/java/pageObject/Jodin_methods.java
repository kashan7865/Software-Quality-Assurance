package pageObject;

import org.joda.time.*;

public class Jodin_methods {
    public Jodin_methods(){

    }

    public static  int Days(LocalDateTime d1,LocalDateTime d2){
        return Days.daysBetween(d1,d2).getDays();
    }
    public  static int Weeks(LocalDateTime d1,LocalDateTime d2){
        return Weeks.weeksBetween(d1,d2).getWeeks();
    }
    public static int Years(LocalDateTime d1, LocalDateTime d2){
        return Years.yearsBetween(d1,d2).getYears();
    }
    public static int Hours(LocalDateTime d1,LocalDateTime d2){
        return Hours.hoursBetween(d1,d2).getHours();
    }
    public static int Minutes(LocalDateTime d1,LocalDateTime d2){
        return Minutes.minutesBetween(d1,d2).getMinutes();
    }
    public static int Seconds(LocalDateTime d1,LocalDateTime d2){
        return Seconds.secondsBetween(d1,d2).getSeconds();
    }
}
