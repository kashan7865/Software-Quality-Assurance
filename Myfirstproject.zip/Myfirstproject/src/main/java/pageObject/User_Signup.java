package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class User_Signup {
    WebDriver driver;

   public User_Signup(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }
    public WebElement Sign_in(){
        return driver.findElement(By.xpath("//a[@class='login']") );
    }
    public WebElement create_email(){
        return driver.findElement(By.xpath("//input[@id='email_create']") );
    }
    public WebElement create_account(){
        return driver.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[3]/div[1]/div[1]/div[1]/form[1]/div[1]/div[3]/button[1]/span[1]"));
    }
    public WebElement first_name(){
        return driver.findElement(By.xpath("//input[@id='customer_firstname']"));
    }
    public WebElement last_name(){
        return driver.findElement(By.xpath("//input[@id='customer_lastname']"));
    }
    public WebElement password(){
        return driver.findElement(By.xpath("//input[@id='passwd']"));
    }
    public WebElement address(){
        return driver.findElement(By.xpath("//input[@id='address1']"));
    }
    public WebElement city(){
        return driver.findElement(By.xpath("//input[@id='city']"));
    }
    public WebElement postal_code(){
        return driver.findElement(By.xpath("//input[@id='postcode']"));
    }
    public WebElement mobile_no(){
        return driver.findElement(By.xpath("//input[@id='phone_mobile']"));
    }
    public Select dropdown(){
        Select dropdown=new Select(driver.findElement(By.xpath("//select[@id='id_state']")));
        dropdown.selectByIndex(1);
        return dropdown;
    }
    public WebElement submit_detail(){
       return driver.findElement(By.xpath("//button[@id='submitAccount']"));
    }
    public WebElement user_name(){
        return driver.findElement(By.xpath("//a[@class='account']"));
    }
    public WebElement sign_out(){
        return driver.findElement(By.xpath("//a[@class='logout']"));
    }
}
