package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class Search_product_page {
    WebDriver driver;

    public Search_product_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    public WebElement click_pro(){
        return driver.findElement(By.xpath("//a[contains(text(),'Faded Short Sleeve T-shirts')]"));
    }
    public WebElement Wishlist_option(){
        return driver.findElement(By.xpath("//div[@class='product-container']"));
    }
    public WebElement add_to_wishlist(){
        return driver.findElement(By.xpath("//a[@class='addToWishlist wishlistProd_1']"));
    }
    public WebElement pop_up(){
        return driver.findElement(By.xpath("//p[@class='fancybox-error']"));
    }
    public WebElement close_pop_up(){
        return driver.findElement(By.xpath("//a[@class='fancybox-item fancybox-close']"));
    }
    public String product_name(){
        return driver.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[2]/h5[1]/a[1]")).getText();
    }
}
