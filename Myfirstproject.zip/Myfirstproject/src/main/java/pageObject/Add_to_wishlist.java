package pageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class Add_to_wishlist {
    WebDriver driver;

    public Add_to_wishlist(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    public WebElement Sign_in(){
        return driver.findElement(By.xpath("//a[@class='login']") );
    }
    public WebElement id(){
        return driver.findElement(By.xpath("//input[@id='email']") );
    }
    public WebElement password(){
        return driver.findElement(By.xpath("//input[@id='passwd']") );
    }
    public WebElement submit(){
        return driver.findElement(By.xpath("//button[@id='SubmitLogin']") );
    }
    public WebElement user_name(){
         return driver.findElement(By.xpath("//a[@class='account']"));
    }
    public WebElement search(){
        return driver.findElement(By.xpath("//input[@id='search_query_top']") );
    }
    public WebElement submit_search(){
        return driver.findElement(By.xpath("//button[@name='submit_search']") );
    }
    public String product_name(){
        return driver.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[2]/h5[1]/a[1]")).getText();
    }
    public WebElement Wishlist_option(){
        return driver.findElement(By.xpath("//div[@class='product-container']"));
    }
    public WebElement add_to_wishlist(){
        return driver.findElement(By.xpath("//a[@class='addToWishlist wishlistProd_1']"));
    }
    public WebElement pop_up(){
        return driver.findElement(By.xpath("//p[@class='fancybox-error']"));
    }
    public WebElement close_pop_up(){
        return driver.findElement(By.xpath("//a[@class='fancybox-item fancybox-close']"));
    }
    public String pop_up_text(){
        return driver.findElement(By.xpath("//p[@class='fancybox-error']")).getText();
    }
    public WebElement account_heading(){
        return driver.findElement(By.xpath("//h1[contains(text(),'My account')]"));
    }
    public WebElement click_wishlist(){
        return driver.findElement(By.xpath("//span[contains(text(),'My wishlists')]"));
    }
    public WebElement wishlist_heading(){
        return driver.findElement(By.xpath("//h1[@class='page-heading']"));
    }
    public WebElement click_wishlist_link(){
        return driver.findElement(By.xpath("//a[contains(text(),'My wishlist')]"));
    }
    public WebElement product_title(){
        return driver.findElement(By.xpath("//p[@id='s_title']"));
    }
    public WebElement product_quantity(){
        return driver.findElement(By.xpath("//input[@id='quantity_1_0']"));
    }
}