package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class Home_page {
    WebDriver driver;

    public Home_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public WebElement contact_us_button() {
        return driver.findElement(By.xpath("//a[contains(@href,'http://automationpractice.com/index.php?controller=contact')]"));
    }

    public WebElement Sign_in_button() {
        return driver.findElement(By.xpath("//a[@class='login']"));
    }

    public WebElement women_link() {
        return driver.findElement(By.xpath("//a[@class='sf-with-ul']"));
    }

    public WebElement search() {
        return driver.findElement(By.xpath("//input[@id='search_query_top']"));
    }

    public WebElement submit_search() {
        return driver.findElement(By.xpath("//button[@name='submit_search']"));
    }

    public WebElement sign_out() {
        return driver.findElement(By.xpath("//a[@class='logout']"));
    }
    public WebElement casual_dresses() {
        return driver.findElement(By.xpath("//a[contains(text(),'Casual Dresses')]"));
    }
    public WebElement summer_dresses() {
        return driver.findElement(By.xpath("//a[contains(text(),'Summer Dresses')]"));
    }
    public WebElement women_container() {
        return driver.findElement(By.xpath("//ul[@class='submenu-container clearfix first-in-line-xs']"));
    }

}
