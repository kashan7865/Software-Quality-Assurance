package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class Buy_product {
    WebDriver driver;

    public Buy_product(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }
    public WebElement select_pro(){
        return driver.findElement(By.xpath("//a[@class='sf-with-ul']"));
    }
    public WebElement click_pro(){
        return driver.findElement(By.xpath("//a[contains(text(),'Faded Short Sleeve T-shirts')]"));
    }
    public WebElement add_to_cart(){
        return driver.findElement(By.xpath("//span[contains(text(),'Add to cart')]"));
    }
    public WebElement checkout(){
        return driver.findElement(By.xpath("//a[@class='btn btn-default button button-medium']"));
    }
    public WebElement checkout1(){
        return driver.findElement(By.xpath("//a[@class='button btn btn-default standard-checkout button-medium']"));
    }
    public WebElement id(){
        return driver.findElement(By.xpath("//input[@id='email']"));
    }
    public WebElement password(){
        return driver.findElement(By.xpath("//input[@id='passwd']"));
    }
    public WebElement submit(){
        return driver.findElement(By.xpath("//button[@id='SubmitLogin']"));
    }
    public WebElement checkout2(){
        return driver.findElement(By.xpath("//button[@class='button btn btn-default button-medium']"));
    }
    public WebElement checkbox(){
        return driver.findElement(By.xpath("//input[@id='cgv']"));
    }
    public WebElement checkout3(){
        return driver.findElement(By.xpath("//button[@class='button btn btn-default standard-checkout button-medium']"));
    }


}
