package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.Arrays;
import java.util.List;

public class Summer_dresses_page {
    WebDriver driver;

    public Summer_dresses_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    public List total_products(){
        return Arrays.asList(driver.findElement(By.xpath("(//div[@class='product-count'])[1]")).getText().split(""));
    }
    public int total_containers(){
        return driver.findElements(By.xpath("//div[@class='product-container']")).size();
    }
    public WebElement total_items(){
        return driver.findElement(By.xpath("(//div[@class='product-count'])[1]"));
    }
    public List total_containers1(){
        return Arrays.asList(driver.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[3]/div[2]/ul[1]")).getSize());
    }
    public WebElement prod_1_price(){
        return driver.findElement(By.xpath("(//span[@class='price product-price'])[2]"));
    }
    public WebElement prod_2_price(){
        return driver.findElement(By.xpath("(//span[@class='price product-price'])[4]"));
    }
    public WebElement prod_3_price(){
        return driver.findElement(By.xpath("(//span[@class='price product-price'])[6]"));
    }

    public List<WebElement> prod_price(){
        return driver.findElements(By.xpath("//*[@class='right-block']/div[1]/span[1]"));
    }


}
