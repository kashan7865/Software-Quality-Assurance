package pageObject;

import common.utils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

public class Navigation_page {
    WebDriver driver;
    private utils utilobj=new utils();

    public Navigation_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }
    public void navigation(WebElement menu ,WebElement submenu){
        Actions action=new Actions(driver);
        action.moveToElement(menu).perform();
        utilobj.click(submenu);
    }
}
