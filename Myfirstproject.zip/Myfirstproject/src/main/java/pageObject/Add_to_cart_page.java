package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class Add_to_cart_page {
    WebDriver driver;

    public Add_to_cart_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    public WebElement add_to_cart_button(){
        return driver.findElement(By.xpath("//span[contains(text(),'Add to cart')]"));
    }
    public WebElement checkout_button(){
        return driver.findElement(By.xpath("//a[@class='btn btn-default button button-medium']"));
    }
    public WebElement checkout1(){
        return driver.findElement(By.xpath("//a[@class='button btn btn-default standard-checkout button-medium']"));
    }
    public WebElement checkout2(){
        return driver.findElement(By.xpath("//button[@class='button btn btn-default button-medium']"));
    }
    public WebElement checkbox(){
        return driver.findElement(By.xpath("//input[@id='cgv']"));
    }
    public WebElement checkout3(){
        return driver.findElement(By.xpath("//button[@class='button btn btn-default standard-checkout button-medium']"));
    }

}
