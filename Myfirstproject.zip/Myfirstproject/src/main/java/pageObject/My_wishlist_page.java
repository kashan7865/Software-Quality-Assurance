package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class My_wishlist_page {
    WebDriver driver;

    public My_wishlist_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    public WebElement wishlist1_heading(){
        return driver.findElement(By.xpath("//h1[@class='page-heading']"));
    }
    public WebElement wishlist_link(){
        return driver.findElement(By.xpath("//a[contains(text(),'My wishlist')]"));
    }
    public WebElement product_title(){
        return driver.findElement(By.xpath("//p[@id='s_title']"));
    }
    public WebElement product_quantity(){
        return driver.findElement(By.xpath("//input[@id='quantity_1_0']"));
    }
}

