package pageObject;


import java.util.List;



public class lower_to_higher_page {

    public lower_to_higher_page() {
    }
    public boolean sorting(List<String>arrayList){
            boolean Sorted=true;
            for (int i = 1; i < arrayList.size(); i++) {
                if(arrayList.get(i-1).compareTo(arrayList.get(i)) > 0){
                    Sorted= false;
                    break;
                }
            }
            return Sorted;
        }
    }

