package common;

import org.openqa.selenium.WebElement;
import pageObject.Add_to_wishlist;

import java.util.Random;

public class utils {
    WebElement element;
    Random randomGenerator = new Random( );
    int address = randomGenerator.nextInt(2000);
    int o_ref = randomGenerator.nextInt(2000);

    public utils() {

    }

    /*Contact_us();*/
    public void click(WebElement element) {
        element.click( );
    }
    public void input_text(WebElement element,String input_text){
        element.sendKeys(input_text);
    }

    public String get_text(WebElement element) {
        return element.getText( );
    }

    public void email_address(WebElement element) {
        element.sendKeys("fa16" + address + "@gmail.com");
    }

    public void ref_no(WebElement element) {
        element.sendKeys(String.valueOf(o_ref));
    }

    public void message(WebElement element) {
        element.sendKeys("This is a test message " + o_ref);
    }


    /*Add_to_wishlist();*/
    public void id(WebElement element) {
        element.sendKeys("fa16bse102@gmail.com");
    }

    public void password(WebElement element) {
        element.sendKeys("12345");
    }

    public void search(WebElement element) {
        element.sendKeys("Faded short sleeve");
    }


    /*User_Signup();*/

    public void mail_keys(WebElement element) {
        element.sendKeys("fa16bcs" + address + "@gmail.com");
    }
    public void first_name_keys(WebElement element) {
        element.sendKeys("kashan");
    }
    public void last_name_keys(WebElement element) {
        element.sendKeys("malik");
    }
    public void pass_keys(WebElement element) {
        element.sendKeys("12345");
    }
    public void address_keys(WebElement element) {
        element.sendKeys("690c wah cantt");
    }
    public void city_keys(WebElement element) {
        element.sendKeys("wah cantt");
    }
    public void postal_code_keys(WebElement element) {
        element.sendKeys("00000");
    }
    public void mobile_no_keys(WebElement element) {
        element.sendKeys("0392192");
    }

    /*Buy_product();*/



}